from django.urls import path
from EmployeeApp import views

from django.conf.urls.static import static
from django.conf import settings

urlpatterns=[
    path('department',views.departmentApi),
    path('department/([0-9]+)',views.departmentApi),

    path('',views.employeeApi),
    path('/([0-9]+)',views.employeeApi),

    path('employee/savefile',views.SaveFile)
]+static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)