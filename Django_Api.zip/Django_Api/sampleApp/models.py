from django.db import models

# Create your models here.

class pirateShip(models.Model):
    shipId = models.AutoField(primary_key=True)
    shipName = models.CharField(max_length=300)


class pirateMember(models.Model):
    memberId = models.AutoField(primary_key=True)
    memberName = models.CharField(max_length=300)
    memberDevilFruit = models.CharField(max_length=300)
    dateOfJoining = models.DateField()
    photoFileName = models.CharField(max_length=300)