from rest_framework import serializers
from sampleApp.models import pirateMember,pirateShip

class shipSerializer(serializers.ModelSerializer):
    class Meta:
        model = pirateShip
        fields = ('shipId','shipName')


class memberSerializer(serializers.ModelSerializer):
    class Meta:
        model = pirateMember
        fields = ('memberId','memberName','memberDevilFruit','dateOfJoining','photoFileName')