from django.urls import path
from sampleApp import views

urlpatterns=[
    path('',views.shipApi),
    path('/<int:shipId>',views.shipApi),
]