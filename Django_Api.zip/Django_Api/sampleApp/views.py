from django.shortcuts import render

from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from django.http.response import JsonResponse

from sampleApp.models import pirateMember,pirateShip
from sampleApp.serializers import shipSerializer,memberSerializer

@csrf_exempt
def shipApi(request,shipId=0):
    if request.method == 'GET':
        print(shipId,"gyytyututu")
        # if int(shipId)!=0:
        #     ship = pirateShip.objects.get(shipId=id)
        # else:
        ship = pirateShip.objects.all()
        ship_serializer = shipSerializer(ship,many=True)
        return JsonResponse(ship_serializer.data,safe=False)
    elif request.method == 'POST':
        ship_data = JSONParser().parse(request)
        print(ship_data)
        ship_serializer = shipSerializer(data=ship_data)
        if ship_serializer.is_valid():
            ship_serializer.save()
            return JsonResponse('ADDED SUCCESSFULLY',safe=False)
        return JsonResponse('FAILED TO ADD ',safe=False)
    elif request.method == 'PUT':
        ship_data = JSONParser().parse(request)
        ship = pirateShip.objects.get(shipId=ship_data['shipId'])
        ship_serializer = shipSerializer(ship,data=ship_data)
        if ship_serializer.is_valid():
            ship_serializer.save()
            return JsonResponse('UPDATE SUCCESSFULLY',safe=False)
        return JsonResponse('FAILED TO UPDATE')
    elif request.method == 'DELETE':
        ship = pirateShip.objects.get(shipId=id)
        ship.delete()
        return JsonResponse('DELETED SUCCESSFULLY',safe=False)
