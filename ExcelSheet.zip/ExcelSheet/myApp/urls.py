from django.urls import path
from myApp import views



urlpatterns=[
    path('ck',views.departmentApi),
    path('<int:id>',views.departmentApi), 
]