from rest_framework import serializers
from .models import customerDetails

class FileSerializer(serializers.ModelSerializer):
    class Meta:
        model = customerDetails
        fields = ('id','FirstName','LastName','NationalID','PhoneNumber','Email','Occupation','PlaceOfWork','AddressLine1','AddressLine2','HomeNumber','City','Region','PostalCode','Country','Salary','PEP','IDCardFrontUrl','IDCardBackUrl','ResidenceProofUrl','RefferalCode')
        