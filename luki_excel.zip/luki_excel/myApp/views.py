from django.shortcuts import render
import pandas as pd
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
from myApp.serializers import FileSerializer

class ExcelUploadView(APIView):
    def post(self,request):
        file = request.data.get('file')
        print(file)
        if file is None:
            return Response({'error':'No File Uploaded'},status=status.HTTP_400_BAD_REQUEST)
        
        if file.name.endswith('.xlsx'):
            df = pd.read_excel(file,engine='openpyxl')
            print(df)
            records = df.to_dict(orient='records')
            print(records)

            for record in records:
                serializer = FileSerializer(data=record)
                print(serializer)
                print('************&*************')
                if serializer.is_valid():
                    serializer.save()

            return Response({'Message':'Data Uploaded Successfully'},status=status.HTTP_201_CREATED)       
             
        else:
            return Response({'error':'Invalid File Format'},status=status.HTTP_400_BAD_REQUEST)
