# from django.shortcuts import render
# import pandas as pd
# from rest_framework.response import Response
# from rest_framework.views import APIView
# from rest_framework import status
# from myApp.serializers import FileSerializer

# class ExcelUploadView(APIView):
#     def post(self,request):
#         file = request.data.get('file')
#         if file is None:
#             return Response({'error':'No File Uploaded'},status=status.HTTP_400_BAD_REQUEST)
        
#         if file.name.endswith('.xlsx'):
#             df = pd.read_excel(file,engine='openpyxl')
#             records = df.to_dict(orient='records')
#             for record in records:
#                 serializer = FileSerializer(data=record)
#                 if serializer.is_valid():
#                     count =+ 1
#                     serializer.save()

#             return Response({'Message':'Successfully Updated'},status=status.HTTP_201_CREATED)       
             
#         else:
#             return Response({'error':'Invalid File Format'},status=status.HTTP_400_BAD_REQUEST)



# from django.shortcuts import render
# import pandas as pd
# from rest_framework.response import Response
# from rest_framework.views import APIView
# from rest_framework import status
# from myApp.serializers import FileSerializer

# class ExcelUploadView(APIView):
#     def post(self, request):
#         file = request.data.get('file')
#         if file is None:
#             return Response({'error': 'No File Uploaded'}, status=status.HTTP_400_BAD_REQUEST)

#         if file.name.endswith('.xlsx'):
#             df = pd.read_excel(file, engine='openpyxl')
#             num_rows, num_cols = df.shape
#             records = df.to_dict(orient='records')
#             successful_count = 0
#             duplicates = []

#             for record in records:
#                 serializer = FileSerializer(data=record)
#                 if serializer.is_valid():
#                     serializer.save()
#                     successful_count += 1
#                 else:
#                     duplicates.append(record)

#             response_data = {
#                 'Message': 'Successfully Updated',
#                 'Rows': num_rows,
#                 'Columns': num_cols,
#                 'Successful Uploads': successful_count,
#                 'Duplicates': {
#                     'Count': len(duplicates),
#                     'Values': duplicates
#                 }
#             }
#             return Response(response_data, status=status.HTTP_201_CREATED)

#         else:
#             return Response({'error': 'Invalid File Format'}, status=status.HTTP_400_BAD_REQUEST)




from django.shortcuts import render
import pandas as pd
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
from myApp.serializers import FileSerializer
from .models import customerDetails

class ExcelUploadView(APIView):
    def post(self, request):
        file = request.data.get('file')
        if file is None:
            return Response({'error': 'No File Uploaded'}, status=status.HTTP_400_BAD_REQUEST)

        if file.name.endswith('.xlsx'):
            df = pd.read_excel(file, engine='openpyxl')
            num_rows, num_cols = df.shape
            records = df.to_dict(orient='records')
            successful_count = 0
            duplicates = []

            for record in records:
                serializer = FileSerializer(data=record)
                if serializer.is_valid():
                    # Check for duplicates before saving
                    existing_records = customerDetails.objects.filter(Email=record['Email'])
                    if existing_records.exists():
                        duplicates.append(record)
                    else:
                        serializer.save()
                        successful_count += 1
                else:
                    duplicates.append(record)

            response_data = {
                'Message': 'Successfully Updated',
                'Rows': num_rows,
                'Columns': num_cols,
                'Successful Uploads': successful_count,
                'Duplicates': {
                    'Count': len(duplicates),
                    'Values': duplicates
                }
            }
            return Response(response_data, status=status.HTTP_201_CREATED)

        else:
            return Response({'error': 'Invalid File Format'}, status=status.HTTP_400_BAD_REQUEST)


